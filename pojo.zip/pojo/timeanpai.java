package pojo;

public class timeanpai {
	
	private String time;
	private Courseclass courseclass;
	private Room room;
	
	public timeanpai() {
		
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public Courseclass getCourseclass() {
		return courseclass;
	}

	public void setCourseclass(Courseclass courseclass) {
		this.courseclass = courseclass;
	}

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}
	
	

	
}
