package pojo;

import java.util.Objects;

public class XuanKe {
//	private String ccid;
//	private String cname;
//	private String tname;
//	private String time;
//	private String rid;
//	private int class_capacity;
//	private int number;	
	private int grade;
	private Student student;
	private Courseclass courseclass;
	private Teacher teacher;
	
	public XuanKe() {
		
	}
	
	public Teacher getTeacher() {
		return teacher;
	}
	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}
	
	public int getGrade() {
		return grade;
	}

	public void setGrade(int grade) {
		this.grade = grade;
	}

	public Courseclass getCourseclass() {
		return courseclass;
	}

	public void setCourseclass(Courseclass courseclass) {
		this.courseclass = courseclass;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	@Override
	public int hashCode() {
		return Objects.hash(courseclass, grade, student, teacher);
	}

	@Override
	public boolean equals(Object obj) {
			System.out.println("删除成功");
			return true;
	}

	

	//	public String getCcid() {
//		return ccid;
//	}
//	public void setCcid(String ccid) {
//		this.ccid = ccid;
//	}
//	public String getCname() {
//		return cname;
//	}
//	public void setCname(String cname) {
//		this.cname = cname;
//	}
//	public String getTname() {
//		return tname;
//	}
//	public void setTname(String tname) {
//		this.tname = tname;
//	}
//	public String getTime() {
//		return time;
//	}
//	public void setTime(String time) {
//		this.time = time;
//	}
//	public String getRid() {
//		return rid;
//	}
//	public void setRid(String rid) {
//		this.rid = rid;
//	}
//	public int getClass_capacity() {
//		return class_capacity;
//	}
//	public void setClass_capacity(int class_capacity) {
//		this.class_capacity = class_capacity;
//	}
//	public int getNumber() {
//		return number;
//	}
//	public void setNumber(int number) {
//		this.number = number;
//	}
//	@Override
//	public String toString() {
//		return "XuanKe [ccid=" + ccid + ", cname=" + cname + ", tname=" + tname + ", time=" + time + ", rid=" + rid
//				+ ", class_capacity=" + class_capacity + ", number=" + number + "]";
//	}
	
}
