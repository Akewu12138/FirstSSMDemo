package pojo;

public class Courseclass {

	private String ccid;
	private int class_capacity;
	private int number;
	private Course course;
	private Teacher teacher;
	private timeanpai timeap;
	public Courseclass() {
		
	}

	public String getCcid() {
		return ccid;
	}

	public void setCcid(String ccid) {
		this.ccid = ccid;
	}

	public int getClass_capacity() {
		return class_capacity;
	}

	public void setClass_capacity(int class_capacity) {
		this.class_capacity = class_capacity;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}

	public Course getCourse() {
		return course;
	}

	public void setCourse(Course course) {
		this.course = course;
	}

	public Teacher getTeacher() {
		return teacher;
	}

	public void setTeacher(Teacher teacher) {
		this.teacher = teacher;
	}

	public timeanpai getTimeap() {
		return timeap;
	}

	public void setTimeap(timeanpai timeap) {
		this.timeap = timeap;
	}

	@Override
	public String toString() {
		return "Courseclass [ccid=" + ccid + ", class_capacity=" + class_capacity + ", number=" + number + ", course="
				+ course + ", teacher=" + teacher + ", timeap=" + timeap + "]";
	}
	
	
	
}
